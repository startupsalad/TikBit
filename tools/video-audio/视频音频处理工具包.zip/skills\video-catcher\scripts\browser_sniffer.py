# SPDX-License-Identifier: GPL-3.0-only
from __future__ import annotations

from pathlib import Path
import shutil
from typing import Any
from urllib.parse import urlparse

from common import load_netscape_cookies
from media_detector import looks_like_media, rank_candidates
from models import MediaCandidate, SniffResult


NETWORK_MEDIA_HINTS = (
    "videoplayback",
    "mime=video",
    "mime=audio",
    "/video/tos/",
    "/video/",
    "playwm",
    "play_addr",
    "playaddr",
    "playback",
    "master.m3u8",
    "manifest.mpd",
)


def _to_int(value: str | None) -> int:
    try:
        return int(value or 0)
    except ValueError:
        return 0


def _network_looks_media(url: str, content_type: str, resource_type: str = "") -> bool:
    lowered = (url or "").lower()
    return (
        looks_like_media(url, content_type)
        or resource_type == "media"
        or any(token in lowered for token in NETWORK_MEDIA_HINTS)
    )


def _safe_headers(obj: Any) -> dict[str, str]:
    try:
        return dict(obj.all_headers())
    except Exception:
        try:
            return dict(obj.headers)
        except Exception:
            return {}


def _add_dom_candidates(page: Any, candidates: list[MediaCandidate]) -> None:
    """Collect media URLs visible in DOM/performance entries in addition to network events."""
    try:
        rows = page.evaluate(
            """
            () => {
              const out = [];
              for (const el of document.querySelectorAll('video,audio,source')) {
                for (const key of ['currentSrc', 'src']) {
                  const value = el[key];
                  if (typeof value === 'string' && /^https?:/i.test(value)) {
                    out.push({url: value, source: `dom:${el.tagName.toLowerCase()}:${key}`, width: Number(el.videoWidth || 0), height: Number(el.videoHeight || 0)});
                  }
                }
              }
              try {
                for (const e of performance.getEntriesByType('resource')) {
                  if (e && typeof e.name === 'string' && /^https?:/i.test(e.name)) {
                    out.push({url: e.name, source: 'performance'});
                  }
                }
              } catch (_) {}
              return out;
            }
            """
        )
    except Exception:
        return
    for row in rows or []:
        url = str((row or {}).get("url") or "")
        if not url or not _network_looks_media(url, "", ""):
            continue
        candidates.append(
            MediaCandidate(
                url=url,
                source=f"browser-{(row or {}).get('source') or 'dom'}",
                metadata={"resource_type": "media", "width": int((row or {}).get("width") or 0), "height": int((row or {}).get("height") or 0)},
            )
        )


def _launch_context(
    playwright: Any,
    browser_name: str,
    *,
    headed: bool,
    profile_dir: str,
    prefer_system_chrome: bool,
    block_service_workers: bool,
) -> tuple[Any, Any | None, str]:
    browser_type = getattr(playwright, browser_name, None)
    if browser_type is None:
        raise ValueError(f"Unsupported Playwright browser: {browser_name}")

    context_options: dict[str, Any] = {
        "headless": not headed,
        "ignore_https_errors": True,
        "service_workers": "block" if block_service_workers else "allow",
        "args": ["--autoplay-policy=no-user-gesture-required"],
    }

    if profile_dir:
        profile = Path(profile_dir).expanduser()
        profile.mkdir(parents=True, exist_ok=True)
        if browser_name == "chromium" and prefer_system_chrome:
            try:
                context = browser_type.launch_persistent_context(
                    user_data_dir=str(profile),
                    channel="chrome",
                    **context_options,
                )
                return context, None, "system Chrome with isolated video-catcher profile"
            except Exception:
                pass
        if browser_name == "chromium":
            system_chromium = shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome") or shutil.which("google-chrome-stable")
            if system_chromium:
                try:
                    context = browser_type.launch_persistent_context(
                        user_data_dir=str(profile),
                        executable_path=system_chromium,
                        **context_options,
                    )
                    return context, None, f"system Chromium ({system_chromium}) with isolated video-catcher profile"
                except Exception:
                    pass
        context = browser_type.launch_persistent_context(
            user_data_dir=str(profile),
            **context_options,
        )
        return context, None, f"Playwright {browser_name} with isolated persistent profile"

    launch_kwargs: dict[str, Any] = {
        "headless": not headed,
        "args": ["--autoplay-policy=no-user-gesture-required"],
    }
    if browser_name == "chromium":
        system_chromium = shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome") or shutil.which("google-chrome-stable")
        if system_chromium:
            launch_kwargs["executable_path"] = system_chromium
    browser = browser_type.launch(**launch_kwargs)
    context = browser.new_context(
        ignore_https_errors=True,
        service_workers="block" if block_service_workers else "allow",
    )
    return context, browser, f"ephemeral Playwright {browser_name}"


def sniff_browser(
    url: str,
    *,
    seconds: int = 12,
    headed: bool = False,
    cookies_file: str = "",
    browser_name: str = "chromium",
    profile_dir: str = "",
    prefer_system_chrome: bool = True,
    block_service_workers: bool = False,
) -> SniffResult:
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:  # noqa: BLE001
        return SniffResult(url, url, [], note=f"Playwright unavailable: {exc}")

    candidates: list[MediaCandidate] = []
    request_headers_by_url: dict[str, dict[str, str]] = {}
    final_url = url
    browser_cookies: list[dict[str, Any]] = []
    browser = None
    context = None
    launch_note = ""
    navigation_note = ""

    try:
        with sync_playwright() as playwright:
            try:
                context, browser, launch_note = _launch_context(
                    playwright,
                    browser_name,
                    headed=headed,
                    profile_dir=profile_dir,
                    prefer_system_chrome=prefer_system_chrome,
                    block_service_workers=block_service_workers,
                )
                if cookies_file:
                    try:
                        context.add_cookies(load_netscape_cookies(Path(cookies_file)))
                    except Exception as exc:  # noqa: BLE001
                        return SniffResult(url, url, [], note=f"Could not import cookies: {str(exc)[:160]}")

                def on_request(request: Any) -> None:
                    try:
                        request_headers_by_url[request.url] = _safe_headers(request)
                    except Exception:
                        request_headers_by_url[request.url] = {}

                def on_response(response: Any) -> None:
                    headers = _safe_headers(response)
                    content_type = headers.get("content-type", "")
                    request = response.request
                    resource_type = getattr(request, "resource_type", "")
                    if not _network_looks_media(response.url, content_type, resource_type):
                        return
                    candidates.append(
                        MediaCandidate(
                            url=response.url,
                            source="browser-response",
                            content_type=content_type,
                            content_length=_to_int(headers.get("content-length")),
                            status=response.status,
                            request_headers=request_headers_by_url.get(response.url, _safe_headers(request)),
                            response_headers=headers,
                            metadata={
                                "resource_type": resource_type,
                                "page_host": urlparse(final_url or url).netloc.lower(),
                            },
                        )
                    )

                context.on("request", on_request)
                context.on("response", on_response)
                page = context.pages[0] if context.pages else context.new_page()
                try:
                    page.goto(url, wait_until="domcontentloaded", timeout=35_000)
                except Exception as exc:
                    navigation_note = f"navigation failed: {str(exc)[:180]}"
                final_url = page.url or url

                # Trigger media elements already present on the page. Do not click arbitrary UI.
                try:
                    page.evaluate(
                        """
                        () => {
                          for (const el of document.querySelectorAll('video,audio')) {
                            try {
                              el.muted = true;
                              el.preload = 'auto';
                              el.setAttribute('playsinline', '');
                              el.play().catch(() => {});
                            } catch (_) {}
                          }
                        }
                        """
                    )
                except Exception:
                    pass

                # Scroll to trigger lazy-loaded players while avoiding arbitrary interactions.
                steps = max(1, min(4, max(seconds, 1) // 3))
                per_step_ms = max(750, int(max(seconds, 1) * 1000 / steps))
                for index in range(steps):
                    try:
                        page.evaluate(f"window.scrollTo(0, document.body.scrollHeight * {(index + 1) / steps});")
                    except Exception:
                        pass
                    page.wait_for_timeout(per_step_ms)

                _add_dom_candidates(page, candidates)
                try:
                    browser_cookies = context.cookies()
                except Exception:
                    browser_cookies = []
            finally:
                # Persistent contexts own the browser lifetime; closing the context is enough.
                if context is not None:
                    try:
                        context.close()
                    except Exception:
                        pass
                    context = None
                if browser is not None:
                    try:
                        browser.close()
                    except Exception:
                        pass
                    browser = None
    except Exception as exc:  # noqa: BLE001
        return SniffResult(
            url,
            final_url,
            rank_candidates(candidates),
            browser_cookies,
            note=f"browser sniff failed ({launch_note or browser_name}): {str(exc)[:200]}",
        )

    ranked = rank_candidates(candidates)
    return SniffResult(
        url,
        final_url,
        ranked,
        browser_cookies,
        note=(
            f"browser sniff found {len(ranked)} candidate(s) via {launch_note or browser_name}"
            + (f"; {navigation_note}" if navigation_note else "")
        ),
    )
