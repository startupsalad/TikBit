---
name: local-transcribe
description: 当用户要将本地音频/视频文件转成文字、生成字幕/文字稿、转写会议录音/访谈/讲课/播客时使用。完全本地运行，不上传音频，无需 API Key，网络不通也能跑。支持 MP3/WAV/M4A/AAC/FLAC/OGG/MP4/MKV/MOV 等格式，中文/英文/日文/多语言自动检测。引擎：faster-whisper（MIT 协议，CPU/GPU 均可）；Apple Silicon 额外支持 mlx-whisper（MIT）。输出带时间戳的 Markdown 文字稿 + SRT 字幕各一份。首次运行需联网下载 Whisper 模型（medium≈1.5 GB，large-v3≈2.9 GB），下载后离线可用；huggingface.co 不通时自动切换 hf-mirror.com 重试。有 GPU 时自动启用 CUDA 加速，若 cuBLAS 库缺失则静默降级至 CPU+int8，无需手动干预。
argument-hint: "<音频或视频文件路径> [--language zh|en] [--model medium|large-v3]"
license: MIT
allowed-tools: Bash
---

# local-transcribe

本地语音转文字。给一个音频或视频文件，输出带时间戳的 Markdown 文字稿 + SRT 字幕，不上传音频、不消耗云 API 额度。

## 确定 SKILL_DIR

每条命令里的 `${SKILL_DIR}` 都替换成**你 Read 本文件时的绝对路径的父目录**（即包含本 SKILL.md 的文件夹）。

```
Read ~/.claude/skills/local-transcribe/SKILL.md  →  SKILL_DIR=~/.claude/skills/local-transcribe
Read 知识库/.claude/skills/local-transcribe/SKILL.md  →  SKILL_DIR=<知识库绝对路径>/.claude/skills/local-transcribe
```

确认脚本存在（一次即可）：

```bash
SKILL_DIR="<上面确定的绝对路径>"
[ -f "${SKILL_DIR}/scripts/transcribe.py" ] || echo "ERROR: transcribe.py not found"
```

## 适用请求

- "帮我把这段录音/视频转成文字"
- "转写这个会议录音 / 访谈录音 / 课程录音"
- "给这个视频生成 SRT 字幕文件"
- "本地转写，不想上传到云上"
- 用户拖来 .mp3/.wav/.m4a/.mp4/.mkv 等文件并说"转成文字/文字稿/字幕"

不走本 Skill 的情况：
- 用户已有文字稿，只需翻译或整理 → 直接处理文本
- 用户要先下载网络视频再转写 → 先用 video-catcher 下载，再调本 Skill

## 基本用法

```bash
# Windows（必须用 python，不是 python3；PYTHONUTF8=1 防中文乱码）
PYTHONUTF8=1 python "${SKILL_DIR}/scripts/transcribe.py" "C:/path/to/audio.mp3"

# macOS / Linux
python3 "${SKILL_DIR}/scripts/transcribe.py" "/path/to/audio.mp3"
```

默认行为：自动检测语言 · medium 模型 · 自动选引擎和设备 · 输出到音频同目录

## 完整参数

| 参数 | 说明 | 默认值 |
|:---|:---|:---|
| `--language zh\|en\|ja\|auto` | 指定语言（已知语言时提速+提准） | auto |
| `--model medium\|large-v3\|...` | Whisper 模型名 | medium（faster-whisper）|
| `--engine auto\|faster-whisper\|mlx` | 强制指定引擎 | auto |
| `--device cpu\|cuda` | 强制指定设备（faster-whisper） | auto |
| `--output-dir DIR` | 输出目录 | 与源文件同目录 |
| `--print-text` | 转写完同时打印纯文本到终端 | 关 |
| `--condition-on-previous-text` | 启用上下文续写（可能增加幻觉，不推荐） | 关 |
| `--no-vad-filter` | 关闭语音活动检测 | VAD 开 |

常用示例：

```bash
# 中文录音，指定语言加速
PYTHONUTF8=1 python "${SKILL_DIR}/scripts/transcribe.py" "meeting.mp3" --language zh

# 用 large-v3 模型，精度更高
PYTHONUTF8=1 python "${SKILL_DIR}/scripts/transcribe.py" "lecture.mp4" --language zh --model large-v3

# 输出到指定目录
PYTHONUTF8=1 python "${SKILL_DIR}/scripts/transcribe.py" "interview.wav" --output-dir "D:/Transcripts"
```

## 输出格式

转写结束后在输出目录生成两个文件：

- `<源文件名>.md` — 带 `[MM:SS]` 时间戳的 Markdown 文字稿（含引擎/模型元信息行）
- `<源文件名>.srt` — 标准 SRT 字幕文件（`HH:MM:SS,mmm` 时间码）

用 Read 读 `.md` 给用户看文字稿；`.srt` 告知路径供导入视频编辑软件。

## 依赖安装

```bash
# 检查
python -c "import faster_whisper; print('ok')" 2>&1

# 安装（如未安装）
pip install faster-whisper
```

首次转写时 Whisper 模型自动下载到 `~/.cache/huggingface/`：
- **medium**（默认）约 1.5 GB，日常使用足够
- **large-v3** 约 2.9 GB，精度更高，适合重要录音、多口音场合

若 huggingface.co 不通（国内网络常见），脚本自动切 hf-mirror.com 重试，无需手动配置。

## 故障排查

| 现象 | 说明与处理 |
|:---|:---|
| `CUDA run failed … falling back to CPU/int8` | 正常降级，继续等即可；CPU 转写 medium 约实时 1-4x |
| `ModuleNotFoundError: No module named 'faster_whisper'` | `pip install faster-whisper` |
| 输出文字乱码 | Windows 下务必加 `PYTHONUTF8=1` 前缀 |
| 转写结果有大段重复文字 | 不要加 `--condition-on-previous-text`（默认已关） |
| 模型下载极慢 / 卡住 | 脚本自动切 hf-mirror.com；或手动 `set HF_ENDPOINT=https://hf-mirror.com` 后重跑 |
