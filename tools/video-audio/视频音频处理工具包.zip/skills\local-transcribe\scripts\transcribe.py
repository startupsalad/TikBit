#!/usr/bin/env python3
"""Local audio/video transcription using MIT-licensed engines only.

Engine selection:
  - faster-whisper (CTranslate2, MIT) - default everywhere; auto-picks CUDA
    (float16) when a working GPU+cuDNN is available, else CPU (int8).
  - mlx-whisper (MIT, Apple MLX) - used only on Apple Silicon when the
    mlx-whisper package is installed; otherwise falls back to faster-whisper.

Parameter choices below (VAD on, condition_on_previous_text off by default,
Whisper-large-v3 family for Chinese) follow community best practice for
long-form Chinese speech; no code or files were copied from any
non-MIT-licensed skill.

Output: one Markdown transcript (timestamps + text) and one SRT subtitle
file per input, written next to the source unless --output-dir is given.
No txt/json/vtt, to avoid three near-duplicate files per recording.

Network note: on this network huggingface.co itself can be unreachable
while hf-mirror.com responds fine (confirmed by direct test); if a model
isn't cached locally and the default download fails, we retry once via
HF_ENDPOINT=https://hf-mirror.com before giving up.

Usage:
  python transcribe.py recording.m4a --language zh
  python transcribe.py meeting.mp4 --model medium --engine faster-whisper
  python transcribe.py *.mp3 --output-dir ./transcripts --print-text
"""
from __future__ import annotations

import argparse
import os
import platform
import sys
from dataclasses import dataclass
from pathlib import Path


DEFAULT_MODEL_FASTER_WHISPER = "medium"
DEFAULT_MODEL_MLX = "mlx-community/whisper-large-v3-turbo-q4"

AUDIO_VIDEO_EXTS = {
    ".m4a", ".mp3", ".wav", ".aac", ".flac", ".ogg", ".opus",
    ".mp4", ".mov", ".mkv", ".webm", ".avi",
}


@dataclass
class Segment:
    start: float
    end: float
    text: str


def is_apple_silicon() -> bool:
    return sys.platform == "darwin" and platform.machine() == "arm64"


def mlx_available() -> bool:
    try:
        import mlx_whisper  # noqa: F401
        return True
    except Exception:
        return False


def pick_device_and_compute_type(requested_device: str | None) -> tuple[str, str]:
    """Pick (device, compute_type) for faster-whisper.

    Probes CUDA availability via ctranslate2 (cheap, no model load). Falls
    back to CPU/int8 if CUDA isn't present or the probe itself errors —
    a GPU without a working cuDNN install still shows up as "available"
    at the driver level, so we treat any probe failure as "use CPU".
    """
    if requested_device in ("cpu", "cuda"):
        compute_type = "float16" if requested_device == "cuda" else "int8"
        return requested_device, compute_type

    try:
        import ctranslate2
        if ctranslate2.get_cuda_device_count() > 0:
            return "cuda", "float16"
    except Exception:
        pass
    return "cpu", "int8"


def format_timestamp_srt(seconds: float) -> str:
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def format_timestamp_md(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def write_srt(segments: list[Segment], out_path: Path) -> None:
    lines = []
    for i, seg in enumerate(segments, start=1):
        lines.append(str(i))
        lines.append(f"{format_timestamp_srt(seg.start)} --> {format_timestamp_srt(seg.end)}")
        lines.append(seg.text)
        lines.append("")
    out_path.write_text("\n".join(lines), encoding="utf-8")


def write_markdown(segments: list[Segment], out_path: Path, source: Path, engine: str, model: str) -> None:
    lines = [f"# {source.name} 转写", "", f"引擎: {engine} · 模型: {model}", ""]
    for seg in segments:
        lines.append(f"**[{format_timestamp_md(seg.start)}]** {seg.text}")
        lines.append("")
    out_path.write_text("\n".join(lines), encoding="utf-8")


def transcribe_with_mlx(
    audio_path: Path,
    model: str,
    language: str | None,
    condition_on_previous_text: bool,
) -> list[Segment]:
    import mlx_whisper

    result = mlx_whisper.transcribe(
        str(audio_path),
        path_or_hf_repo=model,
        language=language,
        condition_on_previous_text=condition_on_previous_text,
    )
    return [
        Segment(start=float(s["start"]), end=float(s["end"]), text=s["text"].strip())
        for s in result.get("segments", [])
        if s.get("text", "").strip()
    ]


def _load_faster_whisper_model(model: str, device: str, compute_type: str):
    """Load a faster-whisper model, retrying via the hf-mirror endpoint.

    huggingface.co has been observed to be unreachable from this network
    while hf-mirror.com responds normally — if the model isn't already
    cached locally and the default download hangs/fails, retry once
    through the mirror before giving up.
    """
    from faster_whisper import WhisperModel

    try:
        return WhisperModel(model, device=device, compute_type=compute_type)
    except Exception as first_exc:
        if os.environ.get("HF_ENDPOINT"):
            raise  # already using a mirror, no further fallback
        print(
            "[local-transcribe] default download failed, retrying via hf-mirror.com…",
            file=sys.stderr,
        )
        os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
        try:
            return WhisperModel(model, device=device, compute_type=compute_type)
        except Exception:
            raise first_exc


def _run_faster_whisper(
    audio_path: Path,
    model: str,
    device: str,
    compute_type: str,
    language: str | None,
    condition_on_previous_text: bool,
    vad_filter: bool,
) -> list[Segment]:
    whisper_model = _load_faster_whisper_model(model, device, compute_type)
    segments_iter, _info = whisper_model.transcribe(
        str(audio_path),
        language=language,
        condition_on_previous_text=condition_on_previous_text,
        vad_filter=vad_filter,
    )
    # The actual CUDA/cuBLAS work happens lazily while iterating this
    # generator, not during transcribe() or model construction — so the
    # CPU fallback below has to wrap this consumption too, not just load.
    return [
        Segment(start=seg.start, end=seg.end, text=seg.text.strip())
        for seg in segments_iter
        if seg.text.strip()
    ]


def transcribe_with_faster_whisper(
    audio_path: Path,
    model: str,
    language: str | None,
    device: str | None,
    condition_on_previous_text: bool,
    vad_filter: bool,
) -> list[Segment]:
    device, compute_type = pick_device_and_compute_type(device)
    try:
        return _run_faster_whisper(
            audio_path, model, device, compute_type,
            language, condition_on_previous_text, vad_filter,
        )
    except Exception as exc:
        if device != "cuda":
            raise
        print(
            f"[local-transcribe] CUDA run failed ({exc}) — falling back to CPU/int8",
            file=sys.stderr,
        )
        return _run_faster_whisper(
            audio_path, model, "cpu", "int8",
            language, condition_on_previous_text, vad_filter,
        )


def transcribe_one(
    source: Path,
    engine: str,
    model: str,
    language: str | None,
    device: str | None,
    condition_on_previous_text: bool,
    vad_filter: bool,
    output_dir: Path | None,
    print_text: bool,
) -> None:
    if engine == "mlx":
        segments = transcribe_with_mlx(source, model, language, condition_on_previous_text)
    else:
        segments = transcribe_with_faster_whisper(
            source, model, language, device, condition_on_previous_text, vad_filter
        )

    if not segments:
        print(f"[local-transcribe] {source.name}: no speech detected", file=sys.stderr)
        return

    out_dir = output_dir or source.parent
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = source.stem
    md_path = out_dir / f"{stem}.md"
    srt_path = out_dir / f"{stem}.srt"
    write_markdown(segments, md_path, source, engine, model)
    write_srt(segments, srt_path)

    full_text = "".join(seg.text for seg in segments)
    print(f"[local-transcribe] {source.name} -> {md_path.name}, {srt_path.name} ({len(segments)} 段)", file=sys.stderr)
    if print_text:
        print(full_text)


def main() -> None:
    parser = argparse.ArgumentParser(description="本地音视频转写为 Markdown + SRT（MIT 引擎，纯本地）")
    parser.add_argument("sources", nargs="+", help="音频/视频文件路径，支持多个")
    parser.add_argument("--language", default=None, help="语言代码，如 zh；不确定时省略自动检测")
    parser.add_argument("--engine", choices=["auto", "faster-whisper", "mlx"], default="auto")
    parser.add_argument("--model", default=None, help="模型名称，默认按引擎自动选择")
    parser.add_argument("--device", choices=["cpu", "cuda"], default=None, help="仅 faster-whisper：强制指定设备")
    parser.add_argument("--output-dir", default=None, help="输出目录，默认与源文件同目录")
    parser.add_argument("--print-text", action="store_true", help="转写完成后把全文打印到 stdout")
    parser.add_argument(
        "--condition-on-previous-text",
        action="store_true",
        help="跨段延续上下文；中文口语长录音默认关闭以避免重复幻觉循环",
    )
    parser.add_argument("--no-vad-filter", action="store_true", help="关闭静音过滤（仅 faster-whisper）")
    args = parser.parse_args()

    engine = args.engine
    if engine == "auto":
        engine = "mlx" if (is_apple_silicon() and mlx_available()) else "faster-whisper"

    model = args.model or (DEFAULT_MODEL_MLX if engine == "mlx" else DEFAULT_MODEL_FASTER_WHISPER)
    output_dir = Path(args.output_dir) if args.output_dir else None

    sources = []
    for raw in args.sources:
        p = Path(raw)
        if not p.exists():
            print(f"[local-transcribe] 跳过，文件不存在: {raw}", file=sys.stderr)
            continue
        if p.suffix.lower() not in AUDIO_VIDEO_EXTS:
            print(f"[local-transcribe] 跳过，非受支持的音视频格式: {raw}", file=sys.stderr)
            continue
        sources.append(p)

    if not sources:
        raise SystemExit("没有可处理的文件")

    print(f"[local-transcribe] 引擎: {engine} · 模型: {model}", file=sys.stderr)
    for source in sources:
        transcribe_one(
            source=source,
            engine=engine,
            model=model,
            language=args.language,
            device=args.device,
            condition_on_previous_text=args.condition_on_previous_text,
            vad_filter=not args.no_vad_filter,
            output_dir=output_dir,
            print_text=args.print_text,
        )


if __name__ == "__main__":
    main()
