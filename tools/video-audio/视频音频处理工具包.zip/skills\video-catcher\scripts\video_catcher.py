#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

import requests

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from browser_sniffer import sniff_browser
from common import (
    DEFAULT_USER_AGENT,
    clean_url,
    export_browser_cookies,
    find_executable,
    load_netscape_cookies,
    managed_profile_dir,
    python_module_available,
    safe_forward_headers,
    unique_run_dir,
    write_netscape_cookies,
    ytdlp_command,
)
from direct_downloader import download_direct
from media_detector import detect_manifest_drm, rank_candidates, url_kind
from media_muxer import mux_video_audio
from format_inspector import MediaFormat, inspect_manifest_formats, quality_label
from models import DownloadRecord, MediaCandidate, SniffResult
from report import write_download_report, write_formats_report, write_inspect_report, write_task_state
from static_resolver import resolve_static
from stream_downloader import download_stream_ffmpeg
from verifier import verify_video
from ytdlp_downloader import download_ytdlp, format_selector, probe_ytdlp, probe_ytdlp_formats
from youtube_pot import (
    bgutil_plugin_version,
    pot_prerequisites,
    pot_worthy_error,
    provider_server_dir,
    youtube_pot_session,
)


def default_out_root() -> Path:
    env = os.environ.get("VIDEO_CATCHER_OUT", "").strip()
    if env:
        return Path(env).expanduser()
    return Path.cwd() / "Video" / "Downloads"


def _session(cookies_file: str = "") -> requests.Session:
    session = requests.Session()
    session.headers.update({"User-Agent": DEFAULT_USER_AGENT})
    if cookies_file:
        for item in load_netscape_cookies(Path(cookies_file)):
            try:
                session.cookies.set(
                    item["name"], item["value"], domain=item.get("domain"), path=item.get("path") or "/"
                )
            except Exception:
                pass
    return session


def _merge_candidates(*groups: list[MediaCandidate]) -> list[MediaCandidate]:
    merged: list[MediaCandidate] = []
    for group in groups:
        merged.extend(group)
    return rank_candidates(merged)


def _probe_drm(session: requests.Session, candidates: list[MediaCandidate]) -> None:
    for item in candidates:
        if item.kind != "stream":
            continue
        status, note = detect_manifest_drm(session, item)
        item.drm_status = status
        item.drm = status == "protected"
        item.drm_note = note


def _cookie_export_failure(note: str) -> bool:
    lowered = (note or "").lower()
    markers = (
        "could not copy",
        "cookie database",
        "failed to decrypt",
        "dpapi",
        "app-bound",
        "permission denied",
    )
    return any(marker in lowered for marker in markers)


def _is_youtube_url(url: str) -> bool:
    lowered = (url or "").lower()
    return "youtube.com/" in lowered or "youtu.be/" in lowered


def _youtube_pot_enabled(args: argparse.Namespace) -> bool:
    return not bool(getattr(args, "no_youtube_pot", False))


def _youtube_pot_setup_timeout(args: argparse.Namespace) -> int:
    return min(max(int(getattr(args, "timeout", 600) or 600), 120), 600)


def _effective_profile_dir(args: argparse.Namespace) -> str:
    explicit = str(getattr(args, "profile_dir", "") or "").strip()
    if explicit:
        return str(Path(explicit).expanduser())
    if getattr(args, "no_managed_browser", False):
        return ""
    return str(managed_profile_dir(getattr(args, "browser", "chromium")))


def _run_browser_sniff(url: str, args: argparse.Namespace, cookies_file: str = "") -> SniffResult:
    profile_dir = _effective_profile_dir(args)
    first = sniff_browser(
        url,
        seconds=args.sniff_seconds,
        headed=args.headed,
        cookies_file=cookies_file,
        browser_name=args.browser,
        profile_dir=profile_dir,
        prefer_system_chrome=True,
        block_service_workers=False,
    )
    if first.candidates or args.headed or getattr(args, "no_auto_headed_retry", False):
        return first

    second = sniff_browser(
        url,
        seconds=max(args.sniff_seconds, 12),
        headed=True,
        cookies_file=cookies_file,
        browser_name=args.browser,
        profile_dir=profile_dir,
        prefer_system_chrome=True,
        block_service_workers=True,
    )
    return SniffResult(
        page_url=url,
        final_url=second.final_url or first.final_url,
        candidates=_merge_candidates(first.candidates, second.candidates),
        cookies=second.cookies or first.cookies,
        note=f"{first.note}; automatic headed retry: {second.note}",
    )


def _temporary_browser_cookie_export(browser_spec: str) -> tuple[Path | None, str]:
    if not browser_spec:
        return None, ""
    fd, raw = tempfile.mkstemp(prefix="video-catcher-browser-", suffix="-cookies.txt")
    os.close(fd)
    path = Path(raw)
    path.unlink(missing_ok=True)
    ok, note = export_browser_cookies(browser_spec, path)
    if not ok:
        path.unlink(missing_ok=True)
        return None, note
    return path, note


def _file_has_audio(path: Path) -> bool | None:
    _state, _note, payload = verify_video(path)
    streams = payload.get("streams") if isinstance(payload, dict) else None
    if not streams:
        return None
    return any(item.get("codec_type") == "audio" for item in streams)


def _best_audio_candidate(candidates: list[MediaCandidate], video_candidate: MediaCandidate) -> MediaCandidate | None:
    from urllib.parse import urlparse

    video_url = urlparse(video_candidate.url)
    video_parent = video_url.path.rsplit("/", 1)[0]
    ranked: list[tuple[int, int, int, MediaCandidate]] = []
    for item in candidates:
        if item.kind != "audio" or item.score < 0:
            continue
        score = item.score
        audio_url = urlparse(item.url)
        audio_parent = audio_url.path.rsplit("/", 1)[0]
        if item.source == video_candidate.source:
            score += 50
        if audio_url.netloc and audio_url.netloc == video_url.netloc:
            score += 25
        if video_parent and audio_parent and (video_parent == audio_parent or video_parent.startswith(audio_parent) or audio_parent.startswith(video_parent)):
            score += 15
        if item.source.startswith("browser-") and video_candidate.source.startswith("browser-"):
            score += 10
        ranked.append((score, item.score, item.content_length, item))
    return max(ranked, key=lambda row: row[:3], default=(0, 0, 0, None))[3]


def _attach_separate_audio_if_needed(
    record: DownloadRecord,
    video_candidate: MediaCandidate,
    all_candidates: list[MediaCandidate],
    session: requests.Session,
    out_dir: Path,
    args: argparse.Namespace,
) -> DownloadRecord:
    if record.status != "ok" or len(record.files) != 1:
        return record
    audio_candidate = _best_audio_candidate(all_candidates, video_candidate)
    if audio_candidate is None:
        return record
    video_path = Path(record.files[0])
    has_audio = _file_has_audio(video_path)
    if has_audio is True:
        return record
    if has_audio is None:
        record.status = "failed"
        record.note = "separate audio track was detected but ffprobe could not confirm whether the video already has audio"
        return record

    audio_headers = safe_forward_headers(audio_candidate.request_headers, include_authorization=True)
    audio_record = download_direct(
        session,
        audio_candidate.url,
        out_dir,
        headers=audio_headers,
        max_video_mb=args.max_video_mb,
        timeout=min(args.timeout, 180),
    )
    if audio_record.status != "ok" or not audio_record.files:
        record.status = "failed"
        record.note = f"separate audio track was detected but could not be downloaded: {audio_record.note}"
        return record

    audio_path = Path(audio_record.files[0])
    ok, note, merged_path = mux_video_audio(video_path, audio_path, timeout=min(args.timeout, 900))
    if not ok or merged_path is None:
        record.status = "failed"
        record.note = note
        return record

    video_path.unlink(missing_ok=True)
    audio_path.unlink(missing_ok=True)
    record.files = [str(merged_path)]
    record.bytes = merged_path.stat().st_size
    record.strategy += "+separate-audio-mux"
    record.note = note
    return record



def _merge_formats(*groups: list[MediaFormat]) -> list[MediaFormat]:
    by_height: dict[tuple[int, str], MediaFormat] = {}
    no_height: list[MediaFormat] = []
    source_priority = {"yt-dlp": 4, "hls": 3, "dash": 3, "browser": 2, "direct": 1}
    for group in groups:
        for item in group:
            if item.height > 0:
                key = (item.height, item.label)
                current = by_height.get(key)
                if current is None or source_priority.get(item.source, 0) > source_priority.get(current.source, 0):
                    by_height[key] = item
            else:
                no_height.append(item)
    return sorted(by_height.values(), key=lambda value: (value.height, value.width, value.bitrate)) + no_height


def _formats_from_candidates(
    session: requests.Session,
    candidates: list[MediaCandidate],
    notes: list[str],
) -> list[MediaFormat]:
    groups: list[list[MediaFormat]] = []
    for item in candidates:
        if item.drm_status == "protected":
            notes.append(f"format probe skipped DRM-protected candidate: {item.url}")
            continue
        if item.kind == "stream":
            formats, note = inspect_manifest_formats(session, item)
            notes.append(note)
            if formats:
                groups.append(formats)
            continue
        if item.kind == "direct":
            try:
                width = int(item.metadata.get("width") or 0)
                height = int(item.metadata.get("height") or 0)
            except (TypeError, ValueError):
                width = height = 0
            if height:
                groups.append([MediaFormat(
                    source="browser" if item.source.startswith("browser-") else "direct",
                    label=quality_label(height, width),
                    width=width,
                    height=height,
                    container="direct",
                    url=item.url,
                    note="resolution observed from the page media element",
                )])
    return _merge_formats(*groups) if groups else []


def formats_url(args: argparse.Namespace) -> int:
    url = clean_url(args.url)
    out_root = Path(args.out_root).expanduser()
    out_dir = unique_run_dir(out_root, args.title or "formats", dt.date.today().isoformat())
    notes: list[str] = []
    metadata: dict[str, Any] = {}
    temp_browser_cookies: Path | None = None
    effective_cookies = args.cookies_file
    try:
        formats, info, note = probe_ytdlp_formats(
            url,
            cookies_file=args.cookies_file,
            browser_cookies=args.browser_cookies,
            timeout=min(args.timeout, 180),
        )
        notes.append(note)
        metadata = info or {}

        # Mirror the autonomous download fallback chain for format discovery.
        if (
            not formats
            and _is_youtube_url(url)
            and _youtube_pot_enabled(args)
            and pot_worthy_error(note)
        ):
            try:
                with youtube_pot_session(setup_timeout=_youtube_pot_setup_timeout(args)) as pot:
                    notes.append(f"YouTube PO-token provider: {pot.provider}; {pot.note}")
                    formats, info_pot, pot_note = probe_ytdlp_formats(
                        url,
                        cookies_file=args.cookies_file,
                        browser_cookies="",
                        extractor_args=pot.extractor_args,
                        prefer_python_module=True,
                        timeout=min(args.timeout, 180),
                    )
                    notes.append(f"YouTube mweb + PO-token format probe: {pot_note}")
                    if info_pot:
                        metadata = info_pot
            except Exception as exc:  # noqa: BLE001
                notes.append(f"YouTube PO-token provider unavailable: {str(exc)[:220]}")

        if not formats and not getattr(args, "no_impersonation_retry", False):
            retry_browser = args.browser_cookies
            if _cookie_export_failure(note):
                retry_browser = ""
            formats, info_retry, retry_note = probe_ytdlp_formats(
                url,
                cookies_file=args.cookies_file,
                browser_cookies=retry_browser,
                impersonate="chrome",
                timeout=min(args.timeout, 180),
            )
            notes.append(f"yt-dlp impersonation format probe: {retry_note}")
            if info_retry:
                metadata = info_retry
            if not formats and _is_youtube_url(url):
                formats, info_yt, yt_note = probe_ytdlp_formats(
                    url,
                    cookies_file=args.cookies_file,
                    browser_cookies="" if _cookie_export_failure(retry_note) else retry_browser,
                    impersonate="chrome",
                    extractor_args="youtube:player_client=web_safari",
                    timeout=min(args.timeout, 180),
                )
                notes.append(f"YouTube web_safari format probe: {yt_note}")
                if info_yt:
                    metadata = info_yt

        if not effective_cookies and args.browser_cookies:
            temp_browser_cookies, export_note = _temporary_browser_cookie_export(args.browser_cookies)
            notes.append(export_note)
            if temp_browser_cookies:
                effective_cookies = str(temp_browser_cookies)

        if not formats:
            session = _session(effective_cookies)
            static_candidates, static_note = resolve_static(session, url)
            notes.append(static_note)
            _probe_drm(session, static_candidates)
            formats = _formats_from_candidates(session, static_candidates, notes)

            if not formats and not args.no_sniff:
                sniff = _run_browser_sniff(url, args, effective_cookies)
                notes.append(sniff.note)
                sniff_session = _session(effective_cookies)
                for cookie in sniff.cookies:
                    try:
                        sniff_session.cookies.set(cookie["name"], cookie["value"], domain=cookie.get("domain"), path=cookie.get("path") or "/")
                    except Exception:
                        pass
                _probe_drm(sniff_session, sniff.candidates)
                formats = _formats_from_candidates(sniff_session, sniff.candidates, notes)

        formats = _merge_formats(formats)
        md_path, json_path = write_formats_report(out_dir, url, formats, notes, metadata)
        print(out_dir)
        print(md_path)
        print(json_path)
        if not formats:
            print("No downloadable resolution list could be determined.")
            return 1
        for index, item in enumerate(formats, 1):
            resolution = f"{item.width}x{item.height}" if item.width and item.height else item.label
            size = f" ~{item.display_size}" if item.display_size else ""
            codec = f" {item.video_codec}" if item.video_codec else ""
            print(f"{index:02d}. {item.label:12s} {resolution:12s}{codec}{size}")
        return 0
    finally:
        if temp_browser_cookies:
            temp_browser_cookies.unlink(missing_ok=True)

def inspect_url(args: argparse.Namespace) -> int:
    url = clean_url(args.url)
    out_root = Path(args.out_root).expanduser()
    out_dir = unique_run_dir(out_root, args.title or "inspect", dt.date.today().isoformat())
    notes: list[str] = []
    temp_browser_cookies: Path | None = None
    effective_cookies = args.cookies_file
    try:
        ytdlp_candidate, ytdlp_note = probe_ytdlp(
            url, cookies_file=args.cookies_file, browser_cookies=args.browser_cookies
        )
        notes.append(ytdlp_note)

        if not effective_cookies and args.browser_cookies:
            temp_browser_cookies, export_note = _temporary_browser_cookie_export(args.browser_cookies)
            notes.append(export_note)
            if temp_browser_cookies:
                effective_cookies = str(temp_browser_cookies)

        session = _session(effective_cookies)
        static_candidates, static_note = resolve_static(session, url)
        notes.append(static_note)
        groups: list[list[MediaCandidate]] = [static_candidates]
        if ytdlp_candidate:
            groups.append([ytdlp_candidate])

        if args.sniff or (not ytdlp_candidate and not static_candidates):
            sniff = _run_browser_sniff(url, args, effective_cookies)
            notes.append(sniff.note)
            groups.append(sniff.candidates)
        candidates = _merge_candidates(*groups)
        _probe_drm(session, candidates)
        md_path, json_path = write_inspect_report(out_dir, url, candidates, notes)
        print(out_dir)
        print(md_path)
        print(json_path)
        for index, item in enumerate(candidates[:12], 1):
            drm = ""
            if item.drm_status == "protected":
                drm = f" DRM=protected:{item.drm_note}"
            elif item.drm_status == "unknown":
                drm = f" DRM=unknown:{item.drm_note}"
            elif item.drm_status == "clear":
                drm = " DRM=clear"
            print(f"{index:02d}. score={item.score:3d} kind={item.kind:8s} {item.url}{drm}")
        return 0
    finally:
        if temp_browser_cookies:
            temp_browser_cookies.unlink(missing_ok=True)


def _verify_record(record: DownloadRecord) -> DownloadRecord:
    if record.status != "ok" or not record.files:
        return record
    states: list[bool | None] = []
    notes: list[str] = []
    for raw in record.files:
        state, note, payload = verify_video(Path(raw))
        states.append(state)
        notes.append(f"{Path(raw).name}: {note}")
        if payload:
            record.metadata.setdefault("verification", {})[Path(raw).name] = {
                "format": (payload.get("format") or {}).get("format_name"),
                "duration": (payload.get("format") or {}).get("duration"),
            }
    if any(state is False for state in states):
        record.verified = False
        record.status = "failed"
    elif all(state is True for state in states):
        record.verified = True
    else:
        record.verified = None
    record.verification_note = " | ".join(notes)
    return record


def _download_candidate(
    source_url: str,
    candidate: MediaCandidate,
    out_dir: Path,
    session: requests.Session,
    args: argparse.Namespace,
    *,
    cookies_file: str = "",
) -> DownloadRecord:
    if candidate.drm_status == "protected" or candidate.drm:
        return DownloadRecord(
            source_url=source_url,
            strategy="drm-blocked",
            status="failed",
            selected_media_url=candidate.url,
            note=f"Protected stream detected: {candidate.drm_note}; video-catcher does not bypass DRM",
        )
    headers = safe_forward_headers(candidate.request_headers, include_authorization=True)
    if candidate.kind == "direct":
        record = download_direct(
            session, candidate.url, out_dir, headers=headers, max_video_mb=args.max_video_mb, timeout=min(args.timeout, 180)
        )
        record.source_url = source_url
        record.strategy = "sniffed-direct-http" if candidate.source == "browser-response" else "discovered-direct-http"
        record.selected_media_url = candidate.url
        return record
    if candidate.kind == "stream":
        record = download_ytdlp(
            candidate.url,
            out_dir,
            quality=args.quality,
            quality_mode=getattr(args, "quality_mode", "at-most"),
            format_id=getattr(args, "format_id", ""),
            max_video_mb=args.max_video_mb,
            cookies_file=cookies_file or args.cookies_file,
            browser_cookies="" if cookies_file else args.browser_cookies,
            playlist=False,
            subtitles=args.subtitles,
            sub_langs=args.sub_langs,
            embed_thumbnail=args.embed_thumbnail,
            download_archive=args.download_archive,
            headers=headers,
            timeout=args.timeout,
        )
        if record.status != "ok":
            ffmpeg_record = download_stream_ffmpeg(
                session,
                candidate.url,
                out_dir,
                headers=headers,
                quality=args.quality,
                quality_mode=getattr(args, "quality_mode", "at-most"),
                max_video_mb=args.max_video_mb,
                timeout=min(args.timeout, 1800),
            )
            if ffmpeg_record.status == "ok":
                record = ffmpeg_record
            else:
                record.note = f"{record.note}; ffmpeg fallback: {ffmpeg_record.note}".strip("; ")
        record.source_url = source_url
        if record.strategy == "ffmpeg-stream":
            record.strategy = "sniffed-stream/ffmpeg" if candidate.source == "browser-response" else "discovered-stream/ffmpeg"
        else:
            record.strategy = "sniffed-stream/yt-dlp" if candidate.source == "browser-response" else "discovered-stream/yt-dlp"
        record.selected_media_url = candidate.url
        return record
    return DownloadRecord(
        source_url=source_url,
        strategy="candidate-skip",
        note=f"Unsupported candidate kind: {candidate.kind}",
        selected_media_url=candidate.url,
    )


def _try_candidates(
    source_url: str,
    candidates: list[MediaCandidate],
    out_dir: Path,
    session: requests.Session,
    args: argparse.Namespace,
    notes: list[str],
    *,
    label: str,
    cookies_file: str = "",
) -> DownloadRecord | None:
    for candidate in candidates:
        if candidate.score < args.min_score or candidate.kind not in {"direct", "stream"}:
            continue
        attempt = _download_candidate(
            source_url,
            candidate,
            out_dir,
            session,
            args,
            cookies_file=cookies_file,
        )
        if attempt.status == "ok" and candidate.kind == "direct":
            attempt = _attach_separate_audio_if_needed(
                attempt, candidate, candidates, session, out_dir, args
            )
        notes.append(f"{label} candidate score={candidate.score}: {attempt.status} {attempt.note}".strip())
        if attempt.status == "ok":
            return _verify_record(attempt)
    return None


def download_one(url: str, out_dir: Path, args: argparse.Namespace) -> tuple[DownloadRecord, list[str]]:
    url = clean_url(url)
    notes: list[str] = []
    session = _session(args.cookies_file)
    kind = url_kind(url)

    # 1) Explicit direct URL.
    if kind == "direct":
        record = download_direct(
            session,
            url,
            out_dir,
            max_video_mb=args.max_video_mb,
            timeout=min(args.timeout, 180),
        )
        if record.status == "ok" or not args.browser_cookies:
            return _verify_record(record), notes
        # Browser-cookie import is legacy/opt-in only. Never kill or close the user's browser.
        temp_cookie_path, export_note = _temporary_browser_cookie_export(args.browser_cookies)
        notes.append(export_note)
        try:
            if temp_cookie_path:
                retry = download_direct(
                    _session(str(temp_cookie_path)),
                    url,
                    out_dir,
                    max_video_mb=args.max_video_mb,
                    timeout=min(args.timeout, 180),
                )
                if retry.status == "ok":
                    retry.strategy = "direct-http+browser-cookie"
                    return _verify_record(retry), notes
        finally:
            if temp_cookie_path:
                temp_cookie_path.unlink(missing_ok=True)
        return _verify_record(record), notes

    # 2) Explicit stream URL: probe DRM before yt-dlp.
    if kind == "stream":
        candidate = MediaCandidate(url=url, source="input", kind="stream", request_headers={"Referer": url})
        drm_status, drm_note = detect_manifest_drm(session, candidate)
        candidate.drm_status = drm_status
        candidate.drm = drm_status == "protected"
        candidate.drm_note = drm_note
        record = _download_candidate(url, candidate, out_dir, session, args)
        return _verify_record(record), notes

    # 3) Known platform/extractor route. Main-browser cookies are opt-in only.
    record = download_ytdlp(
        url,
        out_dir,
        quality=args.quality,
        quality_mode=getattr(args, "quality_mode", "at-most"),
        format_id=getattr(args, "format_id", ""),
        max_video_mb=args.max_video_mb,
        cookies_file=args.cookies_file,
        browser_cookies=args.browser_cookies,
        playlist=args.playlist,
        subtitles=args.subtitles,
        sub_langs=args.sub_langs,
        embed_thumbnail=args.embed_thumbnail,
        download_archive=args.download_archive,
        timeout=args.timeout,
    )
    notes.append(f"yt-dlp: {record.status} {record.note}".strip())
    if record.status in {"ok", "skipped"}:
        return _verify_record(record), notes

    # 3a) YouTube-specific PO-token route. This is attempted before generic browser
    # impersonation/sniffing because current YouTube enforcement may reject a request
    # before a usable media URL is ever exposed.
    if (
        _is_youtube_url(url)
        and _youtube_pot_enabled(args)
        and pot_worthy_error(record.note)
    ):
        try:
            with youtube_pot_session(setup_timeout=_youtube_pot_setup_timeout(args)) as pot:
                notes.append(f"YouTube PO-token provider: {pot.provider}; {pot.note}")
                pot_retry = download_ytdlp(
                    url,
                    out_dir,
                    quality=args.quality,
                    quality_mode=getattr(args, "quality_mode", "at-most"),
                    format_id=getattr(args, "format_id", ""),
                    max_video_mb=args.max_video_mb,
                    cookies_file=args.cookies_file,
                    browser_cookies="",
                    playlist=args.playlist,
                    subtitles=args.subtitles,
                    sub_langs=args.sub_langs,
                    embed_thumbnail=args.embed_thumbnail,
                    download_archive=args.download_archive,
                    extractor_args=pot.extractor_args,
                    prefer_python_module=True,
                    timeout=args.timeout,
                )
                notes.append(
                    f"YouTube mweb + PO-token retry: {pot_retry.status} {pot_retry.note}".strip()
                )
                if pot_retry.status in {"ok", "skipped"}:
                    pot_retry.strategy = "yt-dlp+youtube-pot"
                    return _verify_record(pot_retry), notes
                record = pot_retry
        except Exception as exc:  # noqa: BLE001
            notes.append(f"YouTube PO-token provider unavailable: {str(exc)[:220]}")

    # 3b) Autonomous yt-dlp retries that do not depend on the user's live Chrome profile.
    # curl_cffi impersonation can help sites that gate requests by TLS/browser fingerprint.
    if not getattr(args, "no_impersonation_retry", False):
        retry_browser_cookies = args.browser_cookies
        if _cookie_export_failure(record.note):
            retry_browser_cookies = ""
            notes.append("main-browser cookie access failed; autonomous retries will not depend on that browser profile")
        retry = download_ytdlp(
            url,
            out_dir,
            quality=args.quality,
            quality_mode=getattr(args, "quality_mode", "at-most"),
            format_id=getattr(args, "format_id", ""),
            max_video_mb=args.max_video_mb,
            cookies_file=args.cookies_file,
            browser_cookies=retry_browser_cookies,
            playlist=args.playlist,
            subtitles=args.subtitles,
            sub_langs=args.sub_langs,
            embed_thumbnail=args.embed_thumbnail,
            download_archive=args.download_archive,
            impersonate="chrome",
            timeout=args.timeout,
        )
        notes.append(f"yt-dlp impersonation retry: {retry.status} {retry.note}".strip())
        if retry.status in {"ok", "skipped"}:
            retry.strategy = "yt-dlp+impersonate"
            return _verify_record(retry), notes
        record = retry

        # YouTube currently recommends client/token-aware fallbacks. web_safari may expose HLS
        # formats that avoid some GVS PO-token requirements, so try it before browser sniffing.
        if _is_youtube_url(url):
            youtube_retry = download_ytdlp(
                url,
                out_dir,
                quality=args.quality,
                quality_mode=getattr(args, "quality_mode", "at-most"),
                format_id=getattr(args, "format_id", ""),
                max_video_mb=args.max_video_mb,
                cookies_file=args.cookies_file,
                browser_cookies="" if _cookie_export_failure(record.note) else retry_browser_cookies,
                playlist=args.playlist,
                subtitles=args.subtitles,
                sub_langs=args.sub_langs,
                embed_thumbnail=args.embed_thumbnail,
                download_archive=args.download_archive,
                impersonate="chrome",
                extractor_args="youtube:player_client=web_safari",
                timeout=args.timeout,
            )
            notes.append(f"YouTube web_safari retry: {youtube_retry.status} {youtube_retry.note}".strip())
            if youtube_retry.status in {"ok", "skipped"}:
                youtube_retry.strategy = "yt-dlp+web-safari"
                return _verify_record(youtube_retry), notes
            record = youtube_retry

    # If the user explicitly supplied --browser-cookies, try exporting them for HTTP/static
    # fallbacks, but failure is non-fatal and never triggers a prompt to close/kill Chrome.
    temp_browser_cookie_path: Path | None = None
    effective_cookies = args.cookies_file
    if not effective_cookies and args.browser_cookies:
        temp_browser_cookie_path, export_note = _temporary_browser_cookie_export(args.browser_cookies)
        notes.append(export_note)
        if temp_browser_cookie_path:
            effective_cookies = str(temp_browser_cookie_path)
        else:
            notes.append("browser cookie export unavailable; continuing with isolated managed-browser fallback")

    try:
        fallback_session = _session(effective_cookies)

        # 4) Static HTML discovery.
        static_candidates, static_note = resolve_static(fallback_session, url)
        notes.append(static_note)
        _probe_drm(fallback_session, static_candidates)
        static_result = _try_candidates(
            url,
            static_candidates,
            out_dir,
            fallback_session,
            args,
            notes,
            label="static",
            cookies_file=effective_cookies,
        )
        if static_result is not None:
            return static_result, notes

        # 5) Browser network sniff fallback. By default this uses a dedicated persistent
        # video-catcher profile, not the user's active Chrome profile, so Windows Chrome
        # DB locking/App-Bound Encryption do not block this route.
        if args.no_sniff:
            return record, notes
        sniff = _run_browser_sniff(url, args, effective_cookies)
        notes.append(sniff.note)
        if not sniff.candidates:
            record.strategy = "fallback-exhausted"
            record.note = f"{record.note}; no media candidates found by static scan or managed browser sniff"
            return record, notes

        sniff_session = _session(effective_cookies)
        for item in sniff.cookies:
            try:
                sniff_session.cookies.set(
                    item["name"], item["value"], domain=item.get("domain"), path=item.get("path") or "/"
                )
            except Exception:
                pass
        _probe_drm(sniff_session, sniff.candidates)

        # Browser may have acquired fresh anonymous/session cookies after page load.
        sniff_cookie_path: Path | None = None
        if sniff.cookies:
            fd, raw = tempfile.mkstemp(prefix="video-catcher-sniff-", suffix="-cookies.txt")
            os.close(fd)
            sniff_cookie_path = Path(raw)
            write_netscape_cookies(sniff.cookies, sniff_cookie_path)
        try:
            sniff_result = _try_candidates(
                url,
                sniff.candidates,
                out_dir,
                sniff_session,
                args,
                notes,
                label="browser",
                cookies_file=str(sniff_cookie_path) if sniff_cookie_path else effective_cookies,
            )
            if sniff_result is not None:
                return sniff_result, notes
        finally:
            if sniff_cookie_path:
                sniff_cookie_path.unlink(missing_ok=True)

        record.strategy = "fallback-exhausted"
        record.note = f"{record.note}; candidates were found but none downloaded successfully"
        return record, notes
    finally:
        if temp_browser_cookie_path:
            temp_browser_cookie_path.unlink(missing_ok=True)

def _read_url_file(path: str) -> list[str]:
    urls = []
    for raw in Path(path).expanduser().read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith(("#", ";")):
            continue
        urls.append(line)
    return urls


def download_command(args: argparse.Namespace) -> int:
    urls = list(args.urls)
    for path in args.url_file:
        urls.extend(_read_url_file(path))
    clean: list[str] = []
    seen: set[str] = set()
    for value in urls:
        url = clean_url(value)
        if url not in seen:
            clean.append(url)
            seen.add(url)
    if not clean:
        raise SystemExit("No valid URLs provided")

    out_root = Path(args.out_root).expanduser()
    if args.run_dir:
        out_dir = Path(args.run_dir).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)
    else:
        out_dir = unique_run_dir(out_root, args.title or "video-download", dt.date.today().isoformat())

    task_config = {
        "urls": clean,
        "title": args.title,
        "quality": args.quality,
        "quality_mode": getattr(args, "quality_mode", "at-most"),
        "format_id": getattr(args, "format_id", ""),
        "max_video_mb": args.max_video_mb,
        "playlist": args.playlist,
        "subtitles": args.subtitles,
        "sub_langs": args.sub_langs,
        "embed_thumbnail": args.embed_thumbnail,
        "download_archive": args.download_archive,
        "browser_cookies": args.browser_cookies,
        "cookies_file": args.cookies_file,
        "sniff_seconds": args.sniff_seconds,
        "browser": args.browser,
        "min_score": args.min_score,
        "timeout": args.timeout,
        "no_sniff": args.no_sniff,
        "headed": args.headed,
        "profile_dir": getattr(args, "profile_dir", ""),
        "no_managed_browser": bool(getattr(args, "no_managed_browser", False)),
        "no_auto_headed_retry": bool(getattr(args, "no_auto_headed_retry", False)),
        "no_impersonation_retry": bool(getattr(args, "no_impersonation_retry", False)),
        "no_youtube_pot": bool(getattr(args, "no_youtube_pot", False)),
    }
    write_task_state(out_dir, task_config)
    records: list[DownloadRecord] = []
    notes: list[str] = []
    for index, url in enumerate(clean, 1):
        print(f"[{index}/{len(clean)}] {url}", flush=True)
        record, item_notes = download_one(url, out_dir, args)
        records.append(record)
        notes.extend(f"{index}: {note}" for note in item_notes)
        print(f"  -> {record.status} via {record.strategy}: {record.note}", flush=True)
    md_path, json_path = write_download_report(out_dir, records, notes)
    print(out_dir)
    print(md_path)
    print(json_path)
    ok = sum(1 for item in records if item.status in {"ok", "skipped"})
    return 0 if ok == len(records) else (2 if ok else 1)


def resume_command(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser()
    task_path = run_dir / "task.json"
    if not task_path.is_file():
        raise SystemExit(f"task.json not found in {run_dir}")
    config = json.loads(task_path.read_text(encoding="utf-8"))
    forwarded = argparse.Namespace(
        urls=config.get("urls") or [],
        url_file=[],
        out_root=str(run_dir.parent),
        run_dir=str(run_dir),
        title=config.get("title") or "resume",
        quality=args.quality or config.get("quality") or "1080",
        quality_mode=getattr(args, "quality_mode", "") or config.get("quality_mode") or "at-most",
        format_id=getattr(args, "format_id", "") or config.get("format_id") or "",
        max_video_mb=args.max_video_mb or config.get("max_video_mb") or 2048,
        cookies_file=args.cookies_file or config.get("cookies_file") or "",
        browser_cookies=args.browser_cookies or config.get("browser_cookies") or "",
        playlist=bool(config.get("playlist")),
        subtitles=bool(config.get("subtitles")),
        sub_langs=config.get("sub_langs") or "zh.*,en.*",
        embed_thumbnail=bool(config.get("embed_thumbnail")),
        download_archive=config.get("download_archive") or "",
        no_sniff=(bool(config.get("no_sniff")) if args.no_sniff is None else args.no_sniff),
        sniff_seconds=args.sniff_seconds or config.get("sniff_seconds") or 12,
        headed=(bool(config.get("headed")) if args.headed is None else args.headed),
        browser=args.browser or config.get("browser") or "chromium",
        min_score=args.min_score or config.get("min_score") or 35,
        timeout=args.timeout or config.get("timeout") or 3600,
        profile_dir=getattr(args, "profile_dir", "") or config.get("profile_dir") or "",
        no_managed_browser=bool(config.get("no_managed_browser")),
        no_auto_headed_retry=bool(config.get("no_auto_headed_retry")),
        no_impersonation_retry=bool(config.get("no_impersonation_retry")),
        no_youtube_pot=(
            bool(config.get("no_youtube_pot"))
            if getattr(args, "no_youtube_pot", None) is None
            else bool(args.no_youtube_pot)
        ),
    )
    return download_command(forwarded)


def doctor_command(_args: argparse.Namespace) -> int:
    pot_ok, pot_note = pot_prerequisites()
    checks: dict[str, Any] = {
        "python": sys.version.split()[0],
        "requests": python_module_available("requests"),
        "yt-dlp": bool(ytdlp_command()),
        "ffmpeg": bool(find_executable("ffmpeg")),
        "ffprobe": bool(find_executable("ffprobe")),
        "playwright-python": python_module_available("playwright"),
        "curl-cffi": python_module_available("curl_cffi"),
        "playwright-chromium": False,
        "system-chromium": find_executable("chromium") or find_executable("chromium-browser") or find_executable("google-chrome") or find_executable("google-chrome-stable") or "",
        "managed-profile": str(managed_profile_dir("chromium")),
        "youtube-pot-plugin": bgutil_plugin_version(),
        "youtube-pot-capable": pot_ok,
        "youtube-pot-note": pot_note,
        "youtube-pot-provider-cache": str(provider_server_dir()),
        "youtube-pot-provider-built": (provider_server_dir() / "build" / "main.js").is_file(),
    }
    if checks["playwright-python"]:
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as playwright:
                checks["playwright-chromium"] = Path(playwright.chromium.executable_path).exists()
        except Exception:
            pass
    print(json.dumps(checks, ensure_ascii=False, indent=2))
    required = checks["requests"] and checks["yt-dlp"] and checks["ffmpeg"] and checks["ffprobe"]
    return 0 if required else 1


def add_common_download_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--out-root", default=str(default_out_root()))
    parser.add_argument("--title", default="")
    parser.add_argument("--quality", default="1080", help="height such as 1080p/4k, or best")
    parser.add_argument("--quality-mode", choices=["at-most", "exact"], default="at-most", help="at-most caps the height; exact requires the requested height")
    parser.add_argument("--format-id", default="", help="advanced: exact yt-dlp video format id; audio is merged automatically when available")
    parser.add_argument("--max-video-mb", type=float, default=2048.0)
    parser.add_argument("--cookies-file", default="")
    parser.add_argument("--browser-cookies", default="", help="yt-dlp browser cookie source, e.g. chrome/firefox/edge")
    parser.add_argument("--playlist", action="store_true")
    parser.add_argument("--subtitles", action="store_true")
    parser.add_argument("--sub-langs", default="zh.*,en.*")
    parser.add_argument("--embed-thumbnail", action="store_true")
    parser.add_argument("--download-archive", default="")
    parser.add_argument("--no-sniff", action="store_true")
    parser.add_argument("--sniff-seconds", type=int, default=12)
    parser.add_argument("--headed", action="store_true")
    parser.add_argument("--browser", choices=["chromium", "firefox", "webkit"], default="chromium")
    parser.add_argument("--profile-dir", default="", help="isolated persistent browser profile; default ~/.video-catcher/profiles/<browser>")
    parser.add_argument("--no-managed-browser", action="store_true", help="disable isolated persistent browser profile")
    parser.add_argument("--no-auto-headed-retry", action="store_true", help="do not retry browser sniff visibly when headless sniff finds nothing")
    parser.add_argument("--no-impersonation-retry", action="store_true", help="disable yt-dlp curl_cffi/browser impersonation retry")
    parser.add_argument("--no-youtube-pot", action="store_true", help="disable automatic YouTube PO-token provider fallback")
    parser.add_argument("--min-score", type=int, default=35)
    parser.add_argument("--timeout", type=int, default=3600)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Agent-friendly video discovery and downloader")
    sub = parser.add_subparsers(dest="command", required=True)

    download = sub.add_parser("download", help="discover and download videos")
    download.add_argument("urls", nargs="*")
    download.add_argument("--url-file", action="append", default=[])
    download.add_argument("--run-dir", default="")
    add_common_download_args(download)
    download.set_defaults(func=download_command)

    formats = sub.add_parser("formats", help="list downloadable video resolutions without downloading")
    formats.add_argument("url")
    formats.add_argument("--out-root", default=str(default_out_root()))
    formats.add_argument("--title", default="formats")
    formats.add_argument("--cookies-file", default="")
    formats.add_argument("--browser-cookies", default="")
    formats.add_argument("--no-sniff", action="store_true")
    formats.add_argument("--sniff-seconds", type=int, default=12)
    formats.add_argument("--headed", action="store_true")
    formats.add_argument("--browser", choices=["chromium", "firefox", "webkit"], default="chromium")
    formats.add_argument("--profile-dir", default="")
    formats.add_argument("--no-managed-browser", action="store_true")
    formats.add_argument("--no-auto-headed-retry", action="store_true")
    formats.add_argument("--no-impersonation-retry", action="store_true")
    formats.add_argument("--no-youtube-pot", action="store_true")
    formats.add_argument("--timeout", type=int, default=3600)
    formats.set_defaults(func=formats_url)

    inspect = sub.add_parser("inspect", help="discover media without downloading")
    inspect.add_argument("url")
    inspect.add_argument("--out-root", default=str(default_out_root()))
    inspect.add_argument("--title", default="inspect")
    inspect.add_argument("--cookies-file", default="")
    inspect.add_argument("--browser-cookies", default="")
    inspect.add_argument("--sniff", action="store_true", help="always perform browser sniffing")
    inspect.add_argument("--sniff-seconds", type=int, default=12)
    inspect.add_argument("--headed", action="store_true")
    inspect.add_argument("--browser", choices=["chromium", "firefox", "webkit"], default="chromium")
    inspect.add_argument("--profile-dir", default="")
    inspect.add_argument("--no-managed-browser", action="store_true")
    inspect.add_argument("--no-auto-headed-retry", action="store_true")
    inspect.set_defaults(func=inspect_url)

    resume = sub.add_parser("resume", help="resume a previous task directory")
    resume.add_argument("run_dir")
    resume.add_argument("--quality", default="")
    resume.add_argument("--quality-mode", choices=["at-most", "exact"], default="")
    resume.add_argument("--format-id", default="")
    resume.add_argument("--max-video-mb", type=float, default=0)
    resume.add_argument("--cookies-file", default="")
    resume.add_argument("--browser-cookies", default="")
    sniff_group = resume.add_mutually_exclusive_group()
    sniff_group.add_argument("--no-sniff", dest="no_sniff", action="store_true", default=None)
    sniff_group.add_argument("--sniff", dest="no_sniff", action="store_false")
    resume.add_argument("--sniff-seconds", type=int, default=0)
    head_group = resume.add_mutually_exclusive_group()
    head_group.add_argument("--headed", dest="headed", action="store_true", default=None)
    head_group.add_argument("--headless", dest="headed", action="store_false")
    resume.add_argument("--browser", choices=["chromium", "firefox", "webkit"], default="")
    resume.add_argument("--min-score", type=int, default=0)
    resume.add_argument("--timeout", type=int, default=0)
    resume.add_argument("--profile-dir", default="")
    pot_group = resume.add_mutually_exclusive_group()
    pot_group.add_argument("--no-youtube-pot", dest="no_youtube_pot", action="store_true", default=None)
    pot_group.add_argument("--youtube-pot", dest="no_youtube_pot", action="store_false")
    resume.set_defaults(func=resume_command)

    doctor = sub.add_parser("doctor", help="check local dependencies")
    doctor.set_defaults(func=doctor_command)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if hasattr(args, "max_video_mb") and args.max_video_mb < 0:
        parser.error("--max-video-mb must be non-negative")
    if hasattr(args, "sniff_seconds") and args.sniff_seconds < 0:
        parser.error("--sniff-seconds must be non-negative")
    if hasattr(args, "quality") and args.quality:
        try:
            format_selector(args.quality, getattr(args, "quality_mode", "at-most") or "at-most", getattr(args, "format_id", ""))
        except ValueError as exc:
            parser.error(str(exc))
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
