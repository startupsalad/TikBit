# Troubleshooting

## 原则

正常 `download URL` 不应在中途让用户选择浏览器、关闭 Chrome 或导 Cookie。

先让自动链路完整跑完：

```text
yt-dlp
→ YouTube PO Token Provider（仅 YouTube 风控错误）
→ impersonation
→ web_safari（YouTube）
→ static discovery
→ managed browser
→ automatic headed retry
```

## `Could not copy Chrome cookie database`

这是用户显式使用 `--browser-cookies chrome` 时可能遇到的兼容问题。

默认处理方式：

- 不要求用户关闭 Chrome。
- 不杀 Chrome 进程。
- 不修改 Chrome 启动参数。
- 放弃依赖该主浏览器 Cookie Profile，继续 Managed Browser fallback。

因此 Agent 不应把“关闭 Chrome”作为默认恢复步骤。

## `Failed to decrypt with DPAPI` / App-Bound Encryption

同样属于主 Chromium Profile Cookie 提取问题。

Managed Browser 使用独立 user-data-dir，并通过正在运行的 BrowserContext 获取本次会话 Cookie，不需要 yt-dlp 解密用户主 Chrome Cookie 数据库。

## YouTube `Sign in to confirm you're not a bot` / 403 / 429 / PO Token

自动顺序：

1. yt-dlp 常规
2. **本地 bgutil PO Token Provider + mweb**
3. curl_cffi impersonation
4. `web_safari` client retry
5. Static discovery
6. Managed Browser Sniff
7. Headed retry

首次命中 PO Token 路线时，Skill 会自动把 `bgutil-ytdlp-pot-provider` 的 provider 源码下载并构建到：

```text
~/.video-catcher/providers/bgutil-ytdlp-pot-provider/1.3.1/
```

运行要求：

- `bgutil-ytdlp-pot-provider` Python plugin
- Node.js >= 20
- npm / npx

任务过程中 provider 只绑定本机 `127.0.0.1` 的临时端口，完成后关闭。如果 provider 安装/构建失败，不要立刻向用户求助，继续后续 fallback。

PO Token 也不是“彻底绕过 YouTube 风控”的保证。如果当前出口 IP 已经直接命中 429/`sorry/index`、内容本身需要账户权限/验证码，自动链路仍可能失败。

## 抖音 `Fresh cookies are needed`

yt-dlp 的抖音 extractor 可能在平台规则变化时要求 fresh cookies，甚至已有 Cookie 仍失败。

video-catcher 会继续：

- curl_cffi impersonation
- 静态 `playAddr/play_addr/downloadAddr` 等字段扫描
- Managed Browser 网络嗅探
- `/video/tos/` extensionless CDN 识别

不要因为 yt-dlp extractor 报 Fresh cookies 就直接结束。

## Browser Sniff 没找到媒体

默认第一次：

- 持久隔离 Profile
- headless
- Service Worker 允许

若没有媒体候选，会自动第二次：

- 同一 Profile
- headed
- Service Worker block

以增加页面真实播放与网络可见性的机会。

可以用：

```bash
python scripts/video_catcher.py inspect "URL" --sniff --sniff-seconds 25
```

做诊断。

## `yt-dlp not installed` / `curl_cffi` 缺失

统一安装：

```bash
python -m pip install -U -r requirements.txt
```

## Playwright / Chromium 缺失

```bash
python -m pip install -U -r requirements.txt
python -m playwright install chromium
```

## ffmpeg / ffprobe 缺失

将 FFmpeg 加入 PATH。

ffmpeg 用于分轨合并，ffprobe 用于最终验证。

## DRM

发现 Widevine / PlayReady / FairPlay / CENC PSSH / SAMPLE-AES DRM 时停止该候选，不绕过。

普通 HLS AES-128 不简单视作 DRM。


## YouTube PO Token provider 构建失败

先运行：

```bash
python scripts/doctor.py
```

重点检查：

```text
youtube-pot-plugin
node-major
npm
npx
youtube-pot-capable
```

Python plugin 统一通过：

```bash
python -m pip install -U -r requirements.txt
```

Provider 源码由 Skill 在第一次需要时自动准备，不要求用户手工 clone 或启动常驻服务。若 GitHub 当时不可访问、npm 安装失败或 Node 版本过低，任务会回退到其余路线。
