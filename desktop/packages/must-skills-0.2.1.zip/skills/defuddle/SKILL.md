---
name: defuddle
description: Extract clean markdown content from web pages using Defuddle CLI, removing clutter and navigation to save tokens. Use instead of WebFetch when the user provides a URL to read or analyze, for online documentation, articles, blog posts, or any standard web page.
---

# Defuddle

Use Defuddle CLI to extract clean readable content from web pages. Prefer over WebFetch for standard web pages — it removes navigation, ads, and clutter, reducing token usage.

If not installed: `npm install -g defuddle`

## Usage

Always use `--md` for markdown output:

```bash
defuddle parse <url> --md
```

Save to file:

```bash
defuddle parse <url> --md -o content.md
```

Extract specific metadata:

```bash
defuddle parse <url> -p title
defuddle parse <url> -p description
defuddle parse <url> -p domain
```

## Output formats

| Flag | Format |
|------|--------|
| `--md` | Markdown (default choice) |
| `--json` | JSON with both HTML and markdown |
| (none) | HTML |
| `-p <name>` | Specific metadata property |


## Installed resources

Read bundled resources relative to this SKILL.md. This tool is installed for the current vault in both Claude and GPT.


## Managed Python runtime

Run bundled Python scripts through `node python.cjs <script-path-relative-to-this-SKILL.md> [arguments]`. This launcher uses the prepared workstation interpreter and isolated tool dependencies. Resolve paths from this Skill directory; keep outputs in the user task folder. Do not use a different bare Python interpreter and then incorrectly report missing packages. Optional models and external login are prepared only for the requested task.
